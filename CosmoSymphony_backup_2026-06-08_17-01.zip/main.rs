// Prevents additional console window on Windows in release, do not remove.
// Force-compile capability index modification - 2026-05-22
#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

use base64::{engine::general_purpose, Engine as _};
use std::fs;
use std::path::PathBuf;
use std::sync::Mutex;
use sysinfo::{CpuRefreshKind, RefreshKind, System};
use tauri::{AppHandle, Manager, WebviewUrl, WebviewWindowBuilder};
use tauri_plugin_log::{Target, TargetKind};

struct AppState {
    sys: Mutex<System>,
    last_refresh: Mutex<std::time::Instant>,
}

struct LaunchArgs(Mutex<Option<String>>);

#[tauri::command]
fn get_telemetry(state: tauri::State<AppState>) -> serde_json::Value {
    let mut sys = match state.sys.lock() {
        Ok(s) => s,
        Err(poisoned) => poisoned.into_inner(),
    };

    let mut last_refresh = match state.last_refresh.lock() {
        Ok(s) => s,
        Err(poisoned) => poisoned.into_inner(),
    };

    // Prevent race conditions by enforcing a minimum 1-second refresh interval
    if last_refresh.elapsed() >= std::time::Duration::from_millis(1000) {
        sys.refresh_cpu_usage();
        sys.refresh_memory();
        *last_refresh = std::time::Instant::now();
    }

    let cpu_usage = sys.global_cpu_usage();
    let total_mem = sys.total_memory() / 1024 / 1024 / 1024; // GB
    let used_mem = sys.used_memory() / 1024 / 1024 / 1024; // GB

    // Helper to spawn hidden process on Windows
    let run_hidden_cmd = |cmd_name: &str, args: &[&str]| -> Option<String> {
        let mut cmd = std::process::Command::new(cmd_name);
        cmd.args(args);
        #[cfg(target_os = "windows")]
        {
            use std::os::windows::process::CommandExt;
            cmd.creation_flags(0x08000000); // CREATE_NO_WINDOW
        }
        cmd.output().ok().and_then(|out| String::from_utf8(out.stdout).ok())
    };

    let gpu_temp = run_hidden_cmd("nvidia-smi", &["--query-gpu=temperature.gpu", "--format=csv,noheader,nounits"])
        .and_then(|s| s.trim().parse::<f32>().ok())
        .unwrap_or(0.0);

    let vram_data = run_hidden_cmd("nvidia-smi", &["--query-gpu=memory.used,memory.total", "--format=csv,noheader,nounits"])
        .and_then(|s| {
            let parts: Vec<&str> = s.split(',').collect();
            if parts.len() >= 2 {
                let used = parts[0].trim().parse::<f32>().ok()? / 1024.0;
                let total = parts[1].trim().parse::<f32>().ok()? / 1024.0;
                Some(format!("{:.1}/{:.1}GB", used, total))
            } else {
                None
            }
        })
        .unwrap_or_else(|| format!("{}/{}GB", used_mem, total_mem));

    serde_json::json!({
        "cpu": format!("{:.1}%", cpu_usage),
        "mem": vram_data,
        "gpu": "RTX 5080",
        "temp": gpu_temp,
        "fps": "STABLE"
    })
}

#[tauri::command]
fn get_launch_args(state: tauri::State<LaunchArgs>) -> Option<String> {
    if let Ok(mut guard) = state.0.lock() {
        guard.take()
    } else {
        None
    }
}

#[tauri::command]
fn cosmo_log(app: AppHandle, msg: String) {
    if let Ok(mut log_path) = app.path().app_data_dir() {
        log_path.push("cosmo_activity.log");

        if let Some(parent) = log_path.parent() {
            let _ = fs::create_dir_all(parent);
        }

        let timestamp = chrono::Local::now().format("%Y-%m-%d %H:%M:%S");
        let line = format!("[{}] {}\n", timestamp, msg);
        let _ = fs::OpenOptions::new()
            .create(true)
            .append(true)
            .open(log_path)
            .and_then(|mut f| {
                use std::io::Write;
                f.write_all(line.as_bytes())
            });
    }
}

#[tauri::command]
async fn select_folder_cmd(app: AppHandle) -> Result<String, String> {
    use tauri_plugin_dialog::DialogExt;
    
    // Offload the blocking OS dialog to a worker thread to keep the main event loop fluid
    let folder = app.dialog().file().blocking_pick_folder();

    if let Some(path) = folder {
        Ok(path.to_string())
    } else {
        Err("Cancelled".into())
    }
}

#[tauri::command]
async fn get_folder_videos(path: String, mode: String) -> Result<Vec<serde_json::Value>, String> {
    tauri::async_runtime::spawn_blocking(move || {
        let mut vids = Vec::new();
        let video_exts = ["mp4", "webm", "mov", "m4v", "3gp", "avi", "mkv", "flv", "wmv"];
        let image_exts = ["jpg", "jpeg", "png", "gif", "webp", "bmp", "svg", "tiff"];
        
        let target_exts: Vec<&str> = if mode == "picture" { 
            image_exts.to_vec() 
        } else if mode == "video" { 
            video_exts.to_vec() 
        } else {
            video_exts.iter().chain(image_exts.iter()).cloned().collect()
        };

        fn scan_dir_recursive(dir: &std::path::Path, target_exts: &[&str], vids: &mut Vec<serde_json::Value>) {
            if let Ok(entries) = fs::read_dir(dir) {
                for entry in entries.flatten() {
                    let p = entry.path();
                    if p.is_dir() {
                        scan_dir_recursive(&p, target_exts, vids);
                    } else if let Some(ext) = p.extension().and_then(|s| s.to_str()) {
                        if target_exts.contains(&ext.to_lowercase().as_str()) {
                            if let Some(name) = p.file_name().and_then(|s| s.to_str()) {
                                vids.push(serde_json::json!({
                                    "name": name,
                                    "url": p.to_string_lossy().to_string()
                                }));
                            }
                        }
                    }
                }
            }
        }

        scan_dir_recursive(std::path::Path::new(&path), &target_exts, &mut vids);
        Ok(vids)
    }).await.map_err(|e| e.to_string())?
}

/// Extracts a single video frame at `timestamp_secs` using FFmpeg and saves it as a PNG.
/// This is the reliable path for video snapshots — canvas.drawImage() is tainted
/// when videos are served via the cosmo:// custom protocol in WebView2.
#[tauri::command]
async fn snapshot_video_frame(
    real_path: String,
    timestamp_secs: f64,
    file_name: String,
    custom_dir: Option<String>,
) -> Result<String, String> {
    let real_path = real_path.clone();
    let file_name = file_name.clone();
    let custom_dir = custom_dir.clone();

    tauri::async_runtime::spawn_blocking(move || {
        use std::process::Command;
        use std::os::windows::process::CommandExt;
        let base_path = if let Some(d) = custom_dir {
            PathBuf::from(d)
        } else {
            dirs::picture_dir()
                .ok_or("No picture dir")?
                .join("Cosmo_Snapshots")
        };

        let _ = fs::create_dir_all(&base_path);
        let out_path = base_path.join(&file_name);

        // Format timestamp as HH:MM:SS.mmm for ffmpeg -ss
        let total_secs = timestamp_secs as u64;
        let millis = ((timestamp_secs - total_secs as f64) * 1000.0) as u64;
        let hh = total_secs / 3600;
        let mm = (total_secs % 3600) / 60;
        let ss = total_secs % 60;
        let ts_str = format!("{:02}:{:02}:{:02}.{:03}", hh, mm, ss, millis);

        let output = Command::new("ffmpeg")
            .args([
                "-y",
                "-ss", &ts_str,
                "-i", &real_path,
                "-frames:v", "1",
                "-q:v", "1",        // highest quality JPEG/PNG
                "-vf", "scale=iw:ih",  // keep original resolution
                out_path.to_str().ok_or("Bad output path")?,
            ])
            .creation_flags(0x08000000) // CREATE_NO_WINDOW
            .output()
            .map_err(|e| format!("Failed to spawn ffmpeg: {}", e))?;

        if !output.status.success() {
            let stderr = String::from_utf8_lossy(&output.stderr);
            return Err(format!("FFmpeg failed: {}", stderr));
        }

        if !out_path.exists() {
            return Err("FFmpeg ran but output frame was not created".to_string());
        }

        Ok(out_path.to_string_lossy().to_string())
    }).await.map_err(|e| e.to_string())?
}

#[tauri::command]
fn save_snapshot(
    base64_data: String,
    file_name: String,
    custom_dir: Option<String>,
) -> Result<String, String> {
    let data = if base64_data.contains(',') {
        base64_data.split(',').nth(1).ok_or("Invalid base64")?
    } else {
        &base64_data
    };
    let bytes = general_purpose::STANDARD
        .decode(data)
        .map_err(|e| e.to_string())?;

    let base_path = if let Some(d) = custom_dir {
        PathBuf::from(d)
    } else {
        dirs::picture_dir()
            .ok_or("No picture dir")?
            .join("Cosmo_Snapshots")
    };

    let _ = fs::create_dir_all(&base_path);
    let full_path = base_path.join(file_name);
    fs::write(&full_path, bytes).map_err(|e| e.to_string())?;
    Ok(full_path.to_string_lossy().to_string())
}

#[tauri::command]
async fn save_persistence(app: AppHandle, key: String, data: String) {
    let _ = tauri::async_runtime::spawn_blocking(move || {
        if let Ok(mut dir_path) = app.path().app_data_dir() {
            dir_path.push("persistence");
            let _ = fs::create_dir_all(&dir_path);
            
            let file_path = dir_path.join(format!("{}.json", key));
            let bak_path = dir_path.join(format!("{}.json.bak", key));
            let tmp_path = dir_path.join(format!("{}.json.tmp", key));

            let is_json_key = key == "cosmo-v2" || key == "cosmo-video-v2" || key == "cosmo-video" 
                || key == "cosmo-collections" || key == "cosmo-video-collections";
            
            let data_valid = if is_json_key {
                serde_json::from_str::<serde_json::Value>(&data).is_ok()
            } else {
                !data.trim().is_empty()
            };

            if !data_valid {
                eprintln!("[Persistence Warning] Attempted to save invalid/empty data for key: {}", key);
                return;
            }

            // 1. Create a backup of the existing file if it exists and is valid (not empty and valid JSON if JSON key)
            if file_path.exists() {
                if let Ok(existing_content) = fs::read_to_string(&file_path) {
                    let existing_valid = if is_json_key {
                        serde_json::from_str::<serde_json::Value>(&existing_content).is_ok()
                    } else {
                        !existing_content.trim().is_empty()
                    };
                    if existing_valid {
                        let _ = fs::copy(&file_path, &bak_path);
                    }
                }
            }

            // 2. Write to the temporary file
            if fs::write(&tmp_path, &data).is_ok() {
                // 3. Atomically rename/replace the original file with the tmp file
                let _ = fs::rename(&tmp_path, &file_path);
            }

            // 4. Mirror collections and main grid (videos) inside user's Documents folder
            if key == "cosmo-collections" || key == "cosmo-v2" {
                if let Ok(mut doc_path) = app.path().document_dir() {
                    doc_path.push("CosmoSymphony");
                    let _ = fs::create_dir_all(&doc_path);
                    
                    let doc_file_path = doc_path.join(format!("{}.json", key));
                    let doc_tmp_path = doc_path.join(format!("{}.json.tmp", key));
                    
                    if fs::write(&doc_tmp_path, &data).is_ok() {
                        let _ = fs::rename(&doc_tmp_path, &doc_file_path);
                    }
                }
            }
        }
    }).await;
}

#[tauri::command]
async fn load_persistence(app: AppHandle, key: String) -> Option<String> {
    tauri::async_runtime::spawn_blocking(move || {
        let is_json_key = key == "cosmo-v2" || key == "cosmo-video-v2" || key == "cosmo-video" 
            || key == "cosmo-collections" || key == "cosmo-video-collections";

        let is_valid = |content: &str| -> bool {
            if content.trim().is_empty() {
                return false;
            }
            if is_json_key {
                serde_json::from_str::<serde_json::Value>(content).is_ok()
            } else {
                true
            }
        };

        if let Ok(mut dir_path) = app.path().app_data_dir() {
            dir_path.push("persistence");
            let file_path = dir_path.join(format!("{}.json", key));
            let bak_path = dir_path.join(format!("{}.json.bak", key));

            // A. Try reading the primary file
            if file_path.exists() {
                if let Ok(content) = fs::read_to_string(&file_path) {
                    if is_valid(&content) {
                        return Some(content);
                    } else {
                        eprintln!("[Persistence] Primary file for {} is invalid/corrupted.", key);
                    }
                }
            }

            // B. Fallback to the backup file if primary fails
            if bak_path.exists() {
                if let Ok(content) = fs::read_to_string(&bak_path) {
                    if is_valid(&content) {
                        eprintln!("[Persistence] Recovered {} from AppData backup.", key);
                        return Some(content);
                    }
                }
            }
        }

        // C. Fallback to the Documents directory backup
        if key == "cosmo-collections" || key == "cosmo-v2" {
            if let Ok(mut doc_path) = app.path().document_dir() {
                doc_path.push("CosmoSymphony");
                let doc_file_path = doc_path.join(format!("{}.json", key));
                if doc_file_path.exists() {
                    if let Ok(content) = fs::read_to_string(&doc_file_path) {
                        if is_valid(&content) {
                            eprintln!("[Persistence] Recovered {} from Documents backup.", key);
                            return Some(content);
                        }
                    }
                }
            }
        }

        None
    }).await.ok().flatten()
}


#[tauri::command]
fn open_folder(path: String) {
    let resolved_path = if path == "default_snapshots" || path.trim().is_empty() {
        if let Some(pic_dir) = dirs::picture_dir() {
            let snap_dir = pic_dir.join("Cosmo_Snapshots");
            let _ = fs::create_dir_all(&snap_dir);
            snap_dir.to_string_lossy().to_string()
        } else {
            path
        }
    } else {
        path
    };

    // Strip local:// scheme prefix if present (used for cache-busted Tauri asset URLs)
    let stripped = if resolved_path.starts_with("local://") {
        resolved_path.trim_start_matches("local://").to_string()
    } else {
        resolved_path.clone()
    };

    // Strip any query string cache-busters like ?t=1747676254321
    let clean_path = if let Some(idx) = stripped.find('?') {
        stripped[..idx].to_string()
    } else {
        stripped
    };

    // Normalise slashes to Windows backslashes
    let normalized_path = clean_path.replace("/", "\\");
    let p = std::path::Path::new(&normalized_path);

    if !p.exists() {
        println!("System Error: Path not found -> {}", normalized_path);
        return;
    }

    // Call explorer.exe directly — bypasses PowerShell startup lag (~0.5-1s delay)
    // /select highlights the specific file in its folder; directories open directly
    if p.is_dir() {
        let _ = std::process::Command::new("explorer.exe")
            .arg(&normalized_path)
            .spawn();
    } else {
        let _ = std::process::Command::new("explorer.exe")
            .arg("/select,")
            .arg(&normalized_path)
            .spawn();
    }
}

#[tauri::command]
fn exit_app(app: AppHandle) {
    app.exit(0);
}

#[tauri::command]
async fn recycle_unit(path: String) -> Result<(), String> {
    tauri::async_runtime::spawn_blocking(move || {
        trash::delete(&path).map_err(|e| format!("Failed to recycle: {}", e))
    })
    .await
    .map_err(|e| e.to_string())?
}

#[tauri::command]
async fn set_always_on_top(app: AppHandle, flag: bool) {
    if let Some(win) = app.get_webview_window("main") {
        let _ = win.set_always_on_top(flag);
    }
}

#[tauri::command]
async fn rename_video(old_path: String, new_name: String) -> Result<String, String> {
    let old_p = std::path::PathBuf::from(&old_path);
    if !old_p.exists() {
        return Err("Source file not found".into());
    }

    let parent = old_p.parent().ok_or("Invalid parent directory")?;
    let extension = old_p.extension().and_then(|e| e.to_str()).ok_or("File has no extension")?;
    
    // Sanitize new_name to prevent path traversal
    let sanitized_name = new_name.replace(|c: char| !c.is_alphanumeric() && c != ' ' && c != '_' && c != '-', "");
    if sanitized_name.is_empty() {
        return Err("Invalid new name".into());
    }

    let new_filename = format!("{}.{}", sanitized_name, extension);
    let new_p = parent.join(new_filename);

    // Canonicalize to compare and ensure we aren't deleting the same file (e.g. case-only change)
    let canonical_old = std::fs::canonicalize(&old_p).unwrap_or_else(|_| old_p.clone());
    let canonical_new = std::fs::canonicalize(&new_p).unwrap_or_else(|_| new_p.clone());

    if new_p.exists() && canonical_old != canonical_new {
        // OVERWRITE PHILOSOPHY: Physically delete the destination file if it already exists
        let _ = std::fs::remove_file(&new_p);
    }

    let rename_result = std::fs::rename(&old_p, &new_p);
    if rename_result.is_err() {
        // Fallback for cross-filesystem renames, OneDrive, or sync lock errors: Copy and Delete
        std::fs::copy(&old_p, &new_p).map_err(|e| {
            format!(
                "Rename failed and copy fallback failed. Rename error: {:?}. Copy error: {}",
                rename_result.err(),
                e
            )
        })?;
        let _ = std::fs::remove_file(&old_p);
    }

    Ok(new_p.to_string_lossy().to_string())
}

#[tauri::command]
async fn pop_out(app: AppHandle, url: String, title: String) {
    debug_log(&format!("pop_out: Creating window for url={}, title={}", url, title));

    let init_script = format!(
        "window.__POPOUT_DATA__ = {{ popout: true, url: {} }};",
        serde_json::to_string(&url).unwrap_or_else(|_| "\"\"".to_string())
    );

    let label = format!("pop-{}", chrono::Local::now().timestamp_millis());

    // CRITICAL: The main window (tauri.conf.json) sets additionalBrowserArgs.
    // WebView2 requires ALL windows sharing the same user-data directory to
    // have identical browser args — otherwise CreateCoreWebView2Controller
    // returns HRESULT 0x8007139F. Mirror the exact same flags here.
    let mut builder = WebviewWindowBuilder::new(
        &app,
        &label,
        WebviewUrl::App("index.html".into()),
    )
    .initialization_script(&init_script)
    .title(&title)
    .inner_size(800.0, 600.0)
    .resizable(true)
    .decorations(true)
    .visible(false)
    .additional_browser_args("--enable-gpu-rasterization --enable-zero-copy --ignore-gpu-blocklist --enable-features=SharedArrayBuffer")
    .devtools(true);

    // Jump to the other monitor if there are multiple monitors
    if let Ok(monitors) = app.available_monitors() {
        debug_log(&format!("pop_out: Detected {} available monitors", monitors.len()));
        if monitors.len() > 1 {
            if let Some(main_win) = app.get_webview_window("main") {
                if let Ok(Some(current_monitor)) = main_win.current_monitor() {
                    if let Some(other_monitor) = monitors.iter().find(|m| m.name() != current_monitor.name()) {
                        let scale_factor = other_monitor.scale_factor();
                        let position = other_monitor.position();
                        let size = other_monitor.size();

                        let monitor_x = position.x as f64 / scale_factor;
                        let monitor_y = position.y as f64 / scale_factor;
                        let monitor_w = size.width as f64 / scale_factor;
                        let monitor_h = size.height as f64 / scale_factor;

                        let x = monitor_x + (monitor_w - 800.0) / 2.0;
                        let y = monitor_y + (monitor_h - 600.0) / 2.0;

                        debug_log(&format!(
                            "pop_out: Targeting secondary monitor. x={}, y={}",
                            x, y
                        ));
                        builder = builder.position(x, y);
                    }
                }
            }
        }
    }

    match builder.build() {
        Ok(win) => {
            debug_log(&format!("pop_out: Window '{}' built OK, showing...", label));
            // Brief pause to let WebView2 finish internal initialisation
            std::thread::sleep(std::time::Duration::from_millis(200));
            let _ = win.show();
            let _ = win.set_focus();
            debug_log("pop_out: Window shown successfully");
        }
        Err(e) => debug_log(&format!("pop_out: ERROR building window: {:?}", e)),
    }
}

#[tauri::command]
async fn get_video_metadata(app: tauri::AppHandle, path: String) -> Result<serde_json::Value, String> {
    use tauri::Manager;
    // Strip local:// scheme prefix if present
    let stripped = if path.starts_with("local://") {
        path.trim_start_matches("local://").to_string()
    } else {
        path.clone()
    };

    // Strip any query string cache-busters
    let clean_path = if let Some(idx) = stripped.find('?') {
        stripped[..idx].to_string()
    } else {
        stripped
    };

    let p = std::path::PathBuf::from(&clean_path);
    if !p.exists() {
        return Err("File not found".into());
    }

    let metadata = fs::metadata(&p).map_err(|e| e.to_string())?;
    let bytes = metadata.len() as f64;
    
    let size_formatted = if bytes < 1024.0 * 1024.0 {
        format!("{:.1} KB", bytes / 1024.0)
    } else {
        format!("{:.2} MB", bytes / 1024.0 / 1024.0)
    };

    let extension = p.extension()
        .and_then(|s| s.to_str())
        .unwrap_or("unknown")
        .to_uppercase();

    // Check upscale history database
    let mut upscaled_by = None;
    if let Ok(app_data) = app.path().app_data_dir() {
        let history_file = app_data.join("upscale_history.json");
        if let Ok(s) = std::fs::read_to_string(&history_file) {
            if let Ok(history) = serde_json::from_str::<serde_json::Map<String, serde_json::Value>>(&s) {
                // Normalize clean_path or clean_path with backslashes
                let norm_clean = clean_path.replace("/", "\\");
                if let Some(desc) = history.get(&clean_path).or_else(|| history.get(&norm_clean)) {
                    upscaled_by = desc.as_str().map(|s| s.to_string());
                } else if let Ok(abs_path) = std::fs::canonicalize(&p) {
                    let abs_str = abs_path.to_string_lossy().to_string();
                    if let Some(desc) = history.get(&abs_str) {
                        upscaled_by = desc.as_str().map(|s| s.to_string());
                    }
                }
            }
        }
    }

    // Default fallback check based on filename if not in DB
    if upscaled_by.is_none() {
        let file_name = p.file_name().and_then(|s| s.to_str()).unwrap_or("");
        if file_name.contains("_upscaled") {
            upscaled_by = Some("Unknown Model (Pre-existing upscale)".to_string());
        }
    }

    Ok(serde_json::json!({
        "size": size_formatted,
        "format": extension,
        "path": path,
        "name": p.file_name().and_then(|s| s.to_str()).unwrap_or("Unknown"),
        "upscaled_by": upscaled_by
    }))
}

fn debug_log(msg: &str) {
    use std::io::Write;
    if let Ok(mut file) = std::fs::OpenOptions::new()
        .create(true)
        .append(true)
        .open("c:\\Users\\louis\\OneDrive\\Documents\\GitHub\\Video\\rotation_debug.log")
    {
        let _ = writeln!(file, "[{}] {}", chrono::Local::now().format("%Y-%m-%d %H:%M:%S"), msg);
    }
}

#[tauri::command]
async fn rotate_media_on_disk(path: String, rotation: i32, is_image: bool) -> Result<String, String> {
    use std::process::Command;
    use std::path::Path;

    let log_msg = format!("START rotate_media_on_disk: path={}, rotation={}, is_image={}", path, rotation, is_image);
    debug_log(&log_msg);

    let path_obj = Path::new(&path);
    if !path_obj.exists() {
        let err_msg = format!("File does not exist: {}", path);
        debug_log(&err_msg);
        return Err(err_msg);
    }

    let ext = path_obj.extension().ok_or("No extension")?.to_string_lossy().to_lowercase();
    let stem = path_obj.file_stem().ok_or("No file stem")?.to_string_lossy().to_string();

    let normalized_rotation = ((rotation % 360) + 360) % 360;
    debug_log(&format!("normalized_rotation={}", normalized_rotation));
    if normalized_rotation == 0 {
        debug_log("Rotation is 0, returning early");
        return Ok(path);
    }

    let timestamp = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .unwrap_or_default()
        .as_millis();
    
    // Create temp file in system temp directory to prevent OneDrive/sync locks
    let temp_dir = std::env::temp_dir();
    let temp_file_name = format!("{}_rot_{}.{}", stem, timestamp, ext);
    let temp_path = temp_dir.join(&temp_file_name);
    debug_log(&format!("temp_path={:?}", temp_path));

    let mut cmd = Command::new("ffmpeg");
    cmd.arg("-y");

    if is_image {
        cmd.arg("-threads").arg("1");
        // -noautorotate: Prevent ffmpeg from auto-applying EXIF orientation on decode.
        // This ensures we rotate from the RAW pixel orientation (matching what the app shows
        // with imageOrientation: none). Without this, ffmpeg would pre-rotate based on EXIF
        // and our transpose would be applied on top, causing double-rotation.
        let filter = match normalized_rotation {
            90 => "transpose=1",
            180 => "transpose=1,transpose=1",
            270 => "transpose=2",
            _ => "transpose=1",
        };
        cmd.arg("-noautorotate")
           .arg("-i")
           .arg(&path)
           .arg("-vf")
           .arg(filter);

        // Strip ALL metadata (including EXIF orientation tag) to prevent
        // File Explorer from re-applying the old EXIF orientation on top
        // of our already-rotated pixels.
        cmd.arg("-map_metadata").arg("-1");

        // Preserve quality for lossy formats
        if ext == "jpg" || ext == "jpeg" {
            cmd.arg("-q:v").arg("1");
        } else if ext == "webp" {
            cmd.arg("-quality").arg("100");
        }

        cmd.arg("-update").arg("1");

        cmd.arg(temp_path.to_string_lossy().to_string());
    } else {
        // For videos: use stream copy (instant, lossless) with rotation metadata
        let rotate_val = normalized_rotation.to_string();
        cmd.arg("-i")
           .arg(&path)
           .arg("-c")
           .arg("copy")
           .arg("-map_metadata")
           .arg("0")
           .arg("-metadata:s:v:0")
           .arg(format!("rotate={}", rotate_val))
           .arg(temp_path.to_string_lossy().to_string());
    }

    #[cfg(target_os = "windows")]
    {
        use std::os::windows::process::CommandExt;
        cmd.creation_flags(0x08000000); // CREATE_NO_WINDOW
    }

    debug_log(&format!("Running ffmpeg: {:?}", cmd));
    let output = cmd.output().map_err(|e| {
        let err_str = format!("Failed to spawn ffmpeg: {}", e);
        debug_log(&err_str);
        err_str
    })?;
    
    let stdout_str = String::from_utf8_lossy(&output.stdout).to_string();
    let stderr_str = String::from_utf8_lossy(&output.stderr).to_string();
    debug_log(&format!("ffmpeg exit status: {}", output.status));
    debug_log(&format!("ffmpeg stdout: {}", stdout_str));
    debug_log(&format!("ffmpeg stderr: {}", stderr_str));

    if !output.status.success() {
        if temp_path.exists() {
            let _ = std::fs::remove_file(&temp_path);
        }
        let err_str = format!("FFmpeg failed (exit {}): {}", output.status, stderr_str);
        debug_log(&err_str);
        return Err(err_str);
    }

    if !temp_path.exists() {
        let err_str = "FFmpeg ran but output file was not created".to_string();
        debug_log(&err_str);
        return Err(err_str);
    }

    // Overwrite the original file by copying from our isolated temp path (avoids rename lock bugs in OneDrive)
    debug_log(&format!("Copying temp_path {:?} to original path {:?}", temp_path, path));
    if let Err(e) = std::fs::copy(&temp_path, &path) {
        let err_str = format!("Failed to overwrite original file: {}", e);
        debug_log(&err_str);
        return Err(err_str);
    }
    
    let _ = std::fs::remove_file(&temp_path);
    debug_log("SUCCESS — file rotated and saved successfully!");
    Ok(path)
}

#[tauri::command]
async fn mirror_media_on_disk(path: String, is_image: bool) -> Result<String, String> {
    use std::process::Command;
    use std::path::Path;

    debug_log(&format!("START mirror_media_on_disk: path={}, is_image={}", path, is_image));
    tauri::async_runtime::spawn_blocking(move || {
        let path_obj = Path::new(&path);
        if !path_obj.exists() {
            return Err("File does not exist".to_string());
        }

        let ext = path_obj.extension().ok_or("No extension")?.to_string_lossy().to_lowercase();
        let stem = path_obj.file_stem().ok_or("No file stem")?.to_string_lossy().to_string();
        let parent = path_obj.parent().ok_or("No parent dir")?;

        let timestamp = std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .unwrap_or_default()
            .as_millis();
        
        let temp_dir = std::env::temp_dir();
        let temp_file_name = format!("{}_mir_{}.{}", stem, timestamp, ext);
        let temp_path = temp_dir.join(&temp_file_name);

        let mut cmd = Command::new("ffmpeg");
        cmd.arg("-y");

        if is_image {
            cmd.arg("-threads").arg("1");
            cmd.arg("-noautorotate")
               .arg("-i")
               .arg(&path)
               .arg("-vf")
               .arg("hflip")
               .arg("-map_metadata").arg("-1");

            if ext == "jpg" || ext == "jpeg" {
                cmd.arg("-q:v").arg("1");
            } else if ext == "webp" {
                cmd.arg("-quality").arg("100");
            }

            cmd.arg("-update").arg("1");
            cmd.arg(temp_path.to_string_lossy().to_string());
        } else {
            cmd.arg("-i")
               .arg(&path)
               .arg("-vf")
               .arg("hflip")
               .arg("-c:v")
               .arg("libx264")
               .arg("-preset")
               .arg("fast")
               .arg("-crf")
               .arg("22")
               .arg("-c:a")
               .arg("copy")
               .arg(temp_path.to_string_lossy().to_string());
        }

        #[cfg(target_os = "windows")]
        {
            use std::os::windows::process::CommandExt;
            cmd.creation_flags(0x08000000); // CREATE_NO_WINDOW
        }

        debug_log(&format!("Running ffmpeg: {:?}", cmd));
        let output = cmd.output().map_err(|e| format!("Failed to spawn ffmpeg: {}", e))?;

        if !output.status.success() {
            if temp_path.exists() {
                let _ = std::fs::remove_file(&temp_path);
            }
            return Err(format!("FFmpeg mirroring failed: {}", String::from_utf8_lossy(&output.stderr)));
        }

        if !temp_path.exists() {
            return Err("FFmpeg ran but mirror file was not created".to_string());
        }

        debug_log(&format!("Copying temp_path {:?} to original path {:?}", temp_path, path));
        std::fs::copy(&temp_path, &path).map_err(|e| format!("Failed to overwrite original: {}", e))?;
        let _ = std::fs::remove_file(&temp_path);

        Ok(path)
    }).await.map_err(|e| e.to_string())?
}

#[tauri::command]
async fn apply_color_adjustments_on_disk(
    path: String,
    brightness: f32,
    contrast: f32,
    saturation: f32,
    hue: f32,
    gamma: f32,
    final_r: f32,
    final_g: f32,
    final_b: f32,
    alpha: f32,
    negative: bool,
    is_image: bool,
    save_as_copy: bool,
) -> Result<String, String> {
    use std::process::Command;
    use std::path::{Path, PathBuf};

    let log_msg = format!(
        "START apply_color_adjustments_on_disk: path={}, brightness={}, contrast={}, saturation={}, hue={}, gamma={}, final_r={}, final_g={}, final_b={}, alpha={}, negative={}, is_image={}, save_as_copy={}",
        path, brightness, contrast, saturation, hue, gamma, final_r, final_g, final_b, alpha, negative, is_image, save_as_copy
    );
    debug_log(&log_msg);

    let path_obj = Path::new(&path);
    if !path_obj.exists() {
        let err_msg = format!("File does not exist: {}", path);
        debug_log(&err_msg);
        return Err(err_msg);
    }

    let ext = path_obj.extension().ok_or("No extension")?.to_string_lossy().to_lowercase();
    let stem = path_obj.file_stem().ok_or("No file stem")?.to_string_lossy().to_string();
    let parent = path_obj.parent().ok_or("No parent dir")?;

    let timestamp = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .unwrap_or_default()
        .as_millis();
    
    let temp_dir = std::env::temp_dir();
    let temp_file_name = format!("{}_adj_{}.{}", stem, timestamp, ext);
    let temp_path = temp_dir.join(&temp_file_name);
    debug_log(&format!("temp_path={:?}", temp_path));

    let filter_str = format!(
        "lutrgb=r='clip(val*{},0,255)':g='clip(val*{},0,255)':b='clip(val*{},0,255)',eq=contrast={}:saturation={}:gamma={},hue=h={}{}",
        final_r * brightness * alpha,
        final_g * brightness * alpha,
        final_b * brightness * alpha,
        contrast,
        saturation,
        gamma,
        hue,
        if negative { ",negate" } else { "" }
    );
    debug_log(&format!("filter_str={}", filter_str));

    let mut cmd = Command::new("ffmpeg");
    cmd.arg("-y");

    if is_image {
        cmd.arg("-threads")
           .arg("1")
           .arg("-noautorotate")
           .arg("-i")
           .arg(&path)
           .arg("-vf")
           .arg(&filter_str)
           .arg("-map_metadata")
           .arg("-1");

        if ext == "jpg" || ext == "jpeg" {
            cmd.arg("-q:v").arg("1");
        } else if ext == "webp" {
            cmd.arg("-quality").arg("100");
        }
        cmd.arg("-update").arg("1");
        cmd.arg(temp_path.to_string_lossy().to_string());
    } else {
        cmd.arg("-i")
           .arg(&path)
           .arg("-vf")
           .arg(&filter_str)
           .arg("-c:v")
           .arg("libx264")
           .arg("-preset")
           .arg("fast")
           .arg("-crf")
           .arg("22")
           .arg("-c:a")
           .arg("copy")
           .arg(temp_path.to_string_lossy().to_string());
    }

    #[cfg(target_os = "windows")]
    {
        use std::os::windows::process::CommandExt;
        cmd.creation_flags(0x08000000);
    }

    debug_log(&format!("Running ffmpeg: {:?}", cmd));
    let output = cmd.output().map_err(|e| {
        let err_str = format!("Failed to spawn ffmpeg: {}", e);
        debug_log(&err_str);
        err_str
    })?;
    
    let stdout_str = String::from_utf8_lossy(&output.stdout).to_string();
    let stderr_str = String::from_utf8_lossy(&output.stderr).to_string();
    debug_log(&format!("ffmpeg exit status: {}", output.status));
    debug_log(&format!("ffmpeg stdout: {}", stdout_str));
    debug_log(&format!("ffmpeg stderr: {}", stderr_str));

    if !output.status.success() {
        if temp_path.exists() {
            let _ = std::fs::remove_file(&temp_path);
        }
        let err_str = format!("FFmpeg failed (exit {}): {}", output.status, stderr_str);
        debug_log(&err_str);
        return Err(err_str);
    }

    if !temp_path.exists() {
        let err_str = "FFmpeg ran but output file was not created".to_string();
        debug_log(&err_str);
        return Err(err_str);
    }

    let target_path = if save_as_copy {
        let mut index = 0;
        let mut check_path = parent.join(format!("{}_adjusted.{}", stem, ext));
        while check_path.exists() {
            index += 1;
            check_path = parent.join(format!("{}_adjusted.{}.{}", stem, index, ext));
        }
        check_path
    } else {
        PathBuf::from(&path)
    };

    debug_log(&format!("Copying temp_path {:?} to target path {:?}", temp_path, target_path));
    if let Err(e) = std::fs::copy(&temp_path, &target_path) {
        let _ = std::fs::remove_file(&temp_path);
        let err_str = format!("Failed to write to destination: {}", e);
        debug_log(&err_str);
        return Err(err_str);
    }
    
    let _ = std::fs::remove_file(&temp_path);
    debug_log("SUCCESS — file adjustments applied and saved!");
    Ok(target_path.to_string_lossy().to_string())
}

#[tauri::command]
fn get_drag_icon_path() -> Result<String, String> {
    let temp_dir = std::env::temp_dir();
    let icon_path = temp_dir.join("cosmo_drag_icon.png");
    if !icon_path.exists() {
        let bytes = include_bytes!("../icons/32x32.png");
        if let Err(e) = std::fs::write(&icon_path, bytes) {
            return Err(e.to_string());
        }
    }
    Ok(icon_path.to_string_lossy().to_string())
}

fn resolve_enhancer_command(app: Option<&tauri::AppHandle>) -> Result<(std::path::PathBuf, Vec<String>), String> {
    use std::path::PathBuf;
    use tauri::Manager;
    
    let exe_dir = std::env::current_exe()
        .ok()
        .and_then(|p| p.parent().map(|d| d.to_path_buf()));

    // Try to resolve the Python script in the Tauri resources folder
    let resource_py = app.and_then(|a| {
        a.path().resource_dir().ok().map(|d| d.join("resources").join("cosmo_enhance.py")).filter(|p| p.exists())
    });

    let local_exe = exe_dir.as_ref()
        .map(|d| d.join("cosmo_enhance.exe"))
        .filter(|p| p.exists());

    let local_py = resource_py.or_else(|| {
        exe_dir.as_ref()
            .map(|d| d.join("cosmo_enhance.py"))
            .filter(|p| p.exists())
    }).or_else(|| {
        std::env::current_dir()
            .ok()
            .map(|d| d.join("cosmo_enhance.py"))
            .filter(|p| p.exists())
    }).or_else(|| {
        std::env::current_dir()
            .ok()
            .and_then(|d| d.parent().map(|p| p.join("cosmo_enhance.py")))
            .filter(|p| p.exists())
    });

    // 1. Search for sibling CosmoStudio's virtual environment python (fully loaded with PyTorch, CUDA, etc.)
    let mut studio_venv_python = None;
    if let Ok(current_dir) = std::env::current_dir() {
        let mut check_dir = Some(current_dir.as_path());
        while let Some(dir) = check_dir {
            let sibling_studio = dir.join("CosmoStudio");
            let venv_py = sibling_studio.join(".venv").join("Scripts").join("python.exe");
            if venv_py.exists() {
                studio_venv_python = Some(venv_py);
                break;
            }
            check_dir = dir.parent();
        }
    }

    // Search common Python install locations
    let app_data =
        std::env::var_os("LOCALAPPDATA")
            .map(PathBuf::from)
            .unwrap_or_else(|| PathBuf::from(std::env::var_os("USERPROFILE").unwrap_or_default()).join("AppData").join("Local"));
    let program_files =
        std::env::var_os("ProgramFiles")
            .map(PathBuf::from)
            .unwrap_or_else(|| PathBuf::from(r"C:\Program Files"));

    let common_python_paths: Vec<PathBuf> = vec![
        app_data.join("Programs").join("Python").join("Python312").join("python.exe"),
        app_data.join("Programs").join("Python").join("Python311").join("python.exe"),
        program_files.join("Python312").join("python.exe"),
        program_files.join("Python311").join("python.exe"),
        program_files.join("Python310").join("python.exe"),
        PathBuf::from(r"C:\Python312\python.exe"),
        PathBuf::from(r"C:\Python311\python.exe"),
        PathBuf::from(r"C:\Python310\python.exe"),
    ];

    let system_python = studio_venv_python
        .or_else(|| common_python_paths.iter().find(|p| p.exists()).cloned());

    if let Some(exe) = local_exe {
        Ok((exe, vec![]))
    } else if let Some(py_script) = local_py {
        let python_exe = system_python.unwrap_or_else(|| PathBuf::from("python"));
        Ok((python_exe, vec!["-u".to_string(), py_script.to_string_lossy().to_string()]))
    } else if let Some(py_exe) = system_python {
        let script = exe_dir.as_ref()
            .and_then(|d| {
                let s = d.join("cosmo_enhance.py");
                if s.exists() { Some(s) } else { None }
            })
            .or_else(|| {
                std::env::current_dir()
                    .ok()
                    .map(|d| d.join("cosmo_enhance.py"))
                    .filter(|p| p.exists())
            })
            .or_else(|| {
                std::env::current_dir()
                    .ok()
                    .and_then(|d| d.parent().map(|p| p.join("cosmo_enhance.py")))
                    .filter(|p| p.exists())
            })
            .ok_or("cosmo_enhance.py not found in project root or system search directories")?;
        Ok((py_exe, vec!["-u".to_string(), script.to_string_lossy().to_string()]))
    } else {
        Err("No Python found — install Python or place cosmo_enhance.exe in the application directory".into())
    }
}

/// Compute the best models directory path and return it for passing as env var.
fn resolve_models_dir(app: Option<&tauri::AppHandle>) -> Option<String> {
    use tauri::Manager;
    // 1. Check app data dir (MSIX-friendly, user-writable)
    if let Some(app) = app {
        if let Ok(mut app_data) = app.path().app_data_dir() {
            app_data.push(".cosmo_models");
            if app_data.join("RealESRGAN_x4plus.pth").exists() {
                return Some(app_data.to_string_lossy().to_string());
            }
        }
    }
    // 2. Check relative to the exe (covers the project root for dev builds)
    if let Ok(exe) = std::env::current_exe() {
        if let Some(exe_dir) = exe.parent() {
            // Walk up from exe dir looking for .cosmo_models
            let mut dir = Some(exe_dir);
            while let Some(d) = dir {
                let candidate = d.join(".cosmo_models");
                if candidate.join("RealESRGAN_x4plus.pth").exists() {
                    return Some(candidate.to_string_lossy().to_string());
                }
                dir = d.parent();
            }
        }
    }
    // 3. Check APPDATA and USERPROFILE
    if let Some(appdata) = std::env::var_os("APPDATA") {
        let p = std::path::PathBuf::from(appdata).join("com.cosmo.symphony").join(".cosmo_models");
        if p.join("RealESRGAN_x4plus.pth").exists() {
            return Some(p.to_string_lossy().to_string());
        }
    }
    if let Some(home) = std::env::var_os("USERPROFILE") {
        let p = std::path::PathBuf::from(home).join(".cosmo_models");
        if p.join("RealESRGAN_x4plus.pth").exists() {
            return Some(p.to_string_lossy().to_string());
        }
    }
    None
}

fn spawn_enhancement_server(app: Option<&tauri::AppHandle>) -> Result<(), String> {
    use std::process::Command;
    
    let (runner, args) = resolve_enhancer_command(app)?;
    
    let mut cmd = Command::new(&runner);
    cmd.args(&args);
    
    // Pass the models directory so the Python script can find the weights
    if let Some(models_dir) = resolve_models_dir(app) {
        cmd.env("COSMO_MODELS_DIR", &models_dir);
        println!("Passing COSMO_MODELS_DIR={} to enhancement server", models_dir);
    }

    // Set writable current directory so Python libraries don't fail trying to create dirs/files in system folders
    if let Some(app) = app {
        if let Ok(app_data) = app.path().app_data_dir() {
            let _ = std::fs::create_dir_all(&app_data);
            cmd.current_dir(&app_data);
        }
    }
    
    #[cfg(target_os = "windows")]
    {
        use std::os::windows::process::CommandExt;
        cmd.creation_flags(0x08000000); // CREATE_NO_WINDOW
    }
    
    cmd.spawn().map_err(|e| format!("Failed to spawn AI enhancement server: {}", e))?;
    Ok(())
}


fn register_upscale_history(app: &tauri::AppHandle, file_path: &str, used_ai: bool) {
    use tauri::Manager;
    if let Ok(app_data) = app.path().app_data_dir() {
        let history_file = app_data.join("upscale_history.json");
        let mut history: serde_json::Map<String, serde_json::Value> = std::fs::read_to_string(&history_file)
            .ok()
            .and_then(|s| serde_json::from_str(&s).ok())
            .unwrap_or_default();

        let model_desc = if used_ai {
            "Real-ESRGAN x4plus + GFPGAN v1.4 (GPU)"
        } else {
            "Bilateral Filter + INTER_CUBIC (CPU Fallback)"
        };

        history.insert(file_path.to_string(), serde_json::Value::String(model_desc.to_string()));

        if let Ok(s) = serde_json::to_string_pretty(&history) {
            let _ = std::fs::create_dir_all(&app_data);
            let _ = std::fs::write(history_file, s);
        }
    }
}

#[tauri::command]
async fn extract_subject_on_disk(app: tauri::AppHandle, path: String) -> Result<String, String> {
    use std::path::Path;
    use std::io::{Write, Read};
    use std::net::TcpStream;

    let p = Path::new(&path);
    if !p.exists() {
        return Err("File does not exist".into());
    }

    // Connect or auto-spawn the HTTP server on port 12000 first
    let mut stream_connected = TcpStream::connect("127.0.0.1:12000").is_ok();
    
    if !stream_connected {
        println!("AI enhancer server offline. Spawning background server...");
        if let Ok(_) = spawn_enhancement_server(Some(&app)) {
            // Wait for it to boot (up to 15 seconds)
            for _ in 0..30 {
                std::thread::sleep(std::time::Duration::from_millis(500));
                if TcpStream::connect("127.0.0.1:12000").is_ok() {
                    stream_connected = true;
                    println!("AI Enhancement Server booted and connected on port 12000 for cutout!");
                    break;
                }
            }
        }
    }

    if !stream_connected {
        return Err("AI Enhancement Server is offline and could not be started automatically. Please verify local Python dependencies.".into());
    }

    let mut server_success = false;
    let mut sticker_path = String::new();

    if let Ok(mut stream) = TcpStream::connect("127.0.0.1:12000") {
        let json_payload = serde_json::json!({
            "path": path
        }).to_string();

        let request = format!(
            "POST /remove_background HTTP/1.1\r\n\
             Host: 127.0.0.1:12000\r\n\
             Content-Type: application/json\r\n\
             Content-Length: {}\r\n\
             Connection: close\r\n\r\n\
             {}",
            json_payload.len(),
            json_payload
        );

        if stream.write_all(request.as_bytes()).is_ok() {
            let mut response = Vec::new();
            if stream.read_to_end(&mut response).is_ok() {
                let response_str = String::from_utf8_lossy(&response);
                if let Some(pos) = response_str.find("\r\n\r\n") {
                    let body = &response_str[pos + 4..];
                    if let Ok(parsed) = serde_json::from_str::<serde_json::Value>(body) {
                        if parsed.get("status").and_then(|s| s.as_str()) == Some("success") {
                            if let Some(out_p) = parsed.get("path").and_then(|v| v.as_str()) {
                                sticker_path = out_p.to_string();
                                server_success = true;
                            }
                        } else if let Some(err_msg) = parsed.get("error").and_then(|e| e.as_str()) {
                            return Err(format!("Background removal server error: {}", err_msg));
                        }
                    }
                }
            }
        }
    }

    if server_success && !sticker_path.is_empty() {
        Ok(sticker_path)
    } else {
        Err("Failed to process background removal. Make sure 'rembg' Python library is fully installed.".into())
    }
}

#[tauri::command]
async fn upscale_image(app: tauri::AppHandle, path: String, overwrite: bool) -> Result<String, String> {
    use std::process::Command;
    use std::path::Path;
    use std::time::{SystemTime, UNIX_EPOCH};

    let p = Path::new(&path);
    if !p.exists() {
        return Err("File does not exist".into());
    }

    let ext = p.extension()
        .and_then(|s| s.to_str())
        .unwrap_or("png")
        .to_lowercase();
    let Some(stem) = p.file_stem().and_then(|s| s.to_str()) else {
        return Err("Invalid file name".into());
    };

    let timestamp = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .unwrap_or_default()
        .as_millis();

    // Output: temp folder if overwrite, otherwise new _upscaled file in same directory
    let output_path = if overwrite {
        let temp_dir = std::env::temp_dir();
        let temp_file_name = format!("{}_upscale_temp_{}.{}", stem, timestamp, ext);
        temp_dir.join(&temp_file_name)
    } else {
        let parent = p.parent().unwrap_or_else(|| Path::new("."));
        let mut final_path = parent.join(format!("{}_upscaled.{}", stem, ext));
        let mut index = 1;
        while final_path.exists() {
            final_path = parent.join(format!("{}_upscaled.{}.{}", stem, index, ext));
            index += 1;
        }
        final_path
    };

    let out_str = output_path.to_string_lossy().to_string();

    // Connect or auto-spawn the HTTP server on port 12000 first (zero contention, instant, 5080 speed!)
    let mut stream_connected = std::net::TcpStream::connect("127.0.0.1:12000").is_ok();
    
    if !stream_connected {
        println!("AI enhancer server offline. Spawning background server...");
        if let Ok(_) = spawn_enhancement_server(Some(&app)) {
            // Wait for it to boot and warm-load the models (typically 4-8 seconds on first boot)
            for _ in 0..30 {
                std::thread::sleep(std::time::Duration::from_millis(500));
                if std::net::TcpStream::connect("127.0.0.1:12000").is_ok() {
                    stream_connected = true;
                    println!("AI Enhancement Server booted and connected on port 12000!");
                    break;
                }
            }
        }
    }

    let mut server_success = false;
    let mut server_used_ai = false;

    if stream_connected {
        if let Ok(mut stream) = std::net::TcpStream::connect("127.0.0.1:12000") {
            use std::io::{Write, Read};
            let json_payload = serde_json::json!({
                "path": path,
                "output_path": out_str,
                "fidelity": 0.5
            }).to_string();

            let request = format!(
                "POST /enhance HTTP/1.1\r\n\
                 Host: 127.0.0.1:12000\r\n\
                 Content-Type: application/json\r\n\
                 Content-Length: {}\r\n\
                 Connection: close\r\n\r\n\
                 {}",
                json_payload.len(),
                json_payload
            );

            if stream.write_all(request.as_bytes()).is_ok() {
                let mut response = Vec::new();
                if stream.read_to_end(&mut response).is_ok() {
                    let response_str = String::from_utf8_lossy(&response);
                    if let Some(pos) = response_str.find("\r\n\r\n") {
                        let body = &response_str[pos + 4..];
                        if let Ok(parsed) = serde_json::from_str::<serde_json::Value>(body) {
                            if parsed.get("status").and_then(|s| s.as_str()) == Some("success") {
                                let used_ai = parsed.get("used_ai").and_then(|v| v.as_bool()).unwrap_or(false);
                                if !used_ai {
                                    println!("WARNING: Upscale completed but AI models were NOT loaded — fallback resize was used.");
                                }
                                server_success = true;
                                server_used_ai = used_ai;
                            }
                        }
                    }
                }
            }
        }
    }

    if server_success {
        // Prefix the result path with [FALLBACK] if AI wasn't used, so the frontend can warn
        let prefix = if !server_used_ai { "[FALLBACK]" } else { "" };
        let final_saved_path = if overwrite {
            if let Err(e) = std::fs::copy(&output_path, &p) {
                let _ = std::fs::remove_file(&output_path);
                return Err(format!("Failed to overwrite original file: {}", e));
            }
            let _ = std::fs::remove_file(&output_path);
            path.clone()
        } else {
            out_str.clone()
        };

        // Register in upscale history database
        register_upscale_history(&app, &final_saved_path, server_used_ai);

        return Ok(format!("{}{}", prefix, final_saved_path));
    }

    // Fallback: Resolve the script/binary and run in CLI mode
    println!("HTTP server upscale failed or server couldn't start. Falling back to CLI mode...");
    let (runner, mut args) = resolve_enhancer_command(Some(&app))?;
    
    // For CLI mode we append input path and output path
    args.push(path.clone());
    args.push(output_path.to_string_lossy().to_string());

    let mut cmd = Command::new(&runner);
    cmd.args(&args);

    // Set writable current directory so Python libraries don't fail trying to create dirs/files in system folders
    if let Ok(app_data) = app.path().app_data_dir() {
        let _ = std::fs::create_dir_all(&app_data);
        cmd.current_dir(&app_data);
    }

    // Pass models directory to the CLI process
    if let Some(models_dir) = resolve_models_dir(Some(&app)) {
        cmd.env("COSMO_MODELS_DIR", &models_dir);
    }

    #[cfg(target_os = "windows")]
    {
        use std::os::windows::process::CommandExt;
        cmd.creation_flags(0x08000000);
    }

    let log_file = app.path().app_data_dir()
        .ok()
        .map(|mut d| { d.push("upscale.log"); d });

    let output = cmd.output().map_err(|e| format!("Failed to start upscaler: {}", e))?;

    if let Some(ref log_path) = log_file {
        if let Some(parent) = log_path.parent() {
            let _ = std::fs::create_dir_all(parent);
        }
        let _ = std::fs::OpenOptions::new()
            .create(true)
            .append(true)
            .open(log_path)
            .and_then(|mut f| {
                use std::io::Write;
                let t = SystemTime::now().duration_since(UNIX_EPOCH).unwrap_or_default().as_secs();
                writeln!(f, "[{}] exit={} stdout={} stderr={}",
                    t,
                    output.status.code().unwrap_or(-1),
                    String::from_utf8_lossy(&output.stdout),
                    String::from_utf8_lossy(&output.stderr)
                )
            });
    }

    if !output.status.success() {
        if overwrite && output_path.exists() {
            let _ = std::fs::remove_file(&output_path);
        }
        return Err(format!(
            "Upscale failed (exit {:?}): {}",
            output.status.code(),
            String::from_utf8_lossy(&output.stderr).trim()
        ));
    }

    let stdout_str = String::from_utf8_lossy(&output.stdout);
    let cli_used_ai = stdout_str.contains("[USED_AI=True]") || stdout_str.contains("[USED_AI=true]");

    let final_saved_path = if overwrite {
        if let Err(e) = std::fs::copy(&output_path, &p) {
            let _ = std::fs::remove_file(&output_path);
            return Err(format!("Failed to overwrite original file: {}", e));
        }
        let _ = std::fs::remove_file(&output_path);
        path.clone()
    } else {
        output_path.to_string_lossy().to_string()
    };

    // Register in upscale history database
    register_upscale_history(&app, &final_saved_path, cli_used_ai);

    let prefix = if !cli_used_ai { "[FALLBACK]" } else { "" };
    Ok(format!("{}{}", prefix, final_saved_path))
}

#[tauri::command]
fn enhance_image_crop(app: tauri::AppHandle, base64_data: String) -> Result<String, String> {
    use std::io::{Write, Read};
    use std::net::TcpStream;

    let mut stream_connected = TcpStream::connect("127.0.0.1:12000").is_ok();
    
    if !stream_connected {
        println!("AI crop enhancement requested but server is offline. Spawning background server...");
        if let Ok(_) = spawn_enhancement_server(Some(&app)) {
            // Wait for it to boot and warm-load the models
            for _ in 0..30 {
                std::thread::sleep(std::time::Duration::from_millis(500));
                if TcpStream::connect("127.0.0.1:12000").is_ok() {
                    stream_connected = true;
                    println!("AI Enhancement Server booted and connected on port 12000 for crop upscale!");
                    break;
                }
            }
        }
    }
    
    if !stream_connected {
        return Err("Connection to local AI enhancer failed. Make sure Python is installed and the models are available.".into());
    }

    let mut stream = TcpStream::connect("127.0.0.1:12000").map_err(|e| format!("Connection to local AI enhancer failed: {}", e))?;
    
    let json_payload = serde_json::json!({
        "image": base64_data,
        "fidelity": 0.5
    }).to_string();
    
    let request = format!(
        "POST /enhance HTTP/1.1\r\n\
         Host: 127.0.0.1:12000\r\n\
         Content-Type: application/json\r\n\
         Content-Length: {}\r\n\
         Connection: close\r\n\r\n\
         {}",
        json_payload.len(),
        json_payload
    );
    
    stream.write_all(request.as_bytes()).map_err(|e| format!("Failed to send data to AI enhancer: {}", e))?;
    
    let mut response = Vec::new();
    stream.read_to_end(&mut response).map_err(|e| format!("Failed to read response from AI enhancer: {}", e))?;
    
    let response_str = String::from_utf8_lossy(&response);
    
    // Find the end of HTTP headers (\r\n\r\n)
    if let Some(pos) = response_str.find("\r\n\r\n") {
        let body = &response_str[pos + 4..];
        
        // Parse JSON body
        let parsed: serde_json::Value = serde_json::from_str(body).map_err(|e| format!("Upscaling server returned invalid JSON: {}", e))?;
        if let Some(err) = parsed.get("error") {
            return Err(err.as_str().unwrap_or("Unknown server error").to_string());
        }
        
        if let Some(img) = parsed.get("image") {
            if let Some(img_str) = img.as_str() {
                return Ok(img_str.to_string());
            }
        }
        
        Err("Upscaling server returned invalid response format".to_string())
    } else {
        Err("Upscaling server returned invalid HTTP response".to_string())
    }
}


#[tauri::command]
async fn auto_erase_watermark(
    app: tauri::AppHandle,
    path: String,
    rect_x: f64,
    rect_y: f64,
    rect_w: f64,
    rect_h: f64,
    width_disp: f64,
    height_disp: f64,
) -> Result<String, String> {
    use std::io::{Write, Read};
    use std::net::TcpStream;

    let mut stream_connected = TcpStream::connect("127.0.0.1:12000").is_ok();
    
    if !stream_connected {
        println!("Watermark auto-eraser requested but server is offline. Spawning background server...");
        if let Ok(_) = spawn_enhancement_server(Some(&app)) {
            // Wait for it to boot and warm-load the models
            for _ in 0..30 {
                std::thread::sleep(std::time::Duration::from_millis(500));
                if TcpStream::connect("127.0.0.1:12000").is_ok() {
                    stream_connected = true;
                    println!("AI Enhancement Server booted and connected on port 12000 for watermark eraser!");
                    break;
                }
            }
        }
    }
    
    if !stream_connected {
        return Err("Connection to local AI server failed. Make sure Python is installed and the models are available.".into());
    }

    let mut stream = TcpStream::connect("127.0.0.1:12000").map_err(|e| format!("Connection to local AI enhancer failed: {}", e))?;
    
    let json_payload = serde_json::json!({
        "path": path,
        "rect_x": rect_x,
        "rect_y": rect_y,
        "rect_w": rect_w,
        "rect_h": rect_h,
        "width_disp": width_disp,
        "height_disp": height_disp
    }).to_string();
    
    let request = format!(
        "POST /inpaint HTTP/1.1\r\n\
         Host: 127.0.0.1:12000\r\n\
         Content-Type: application/json\r\n\
         Content-Length: {}\r\n\
         Connection: close\r\n\r\n\
         {}",
        json_payload.len(),
        json_payload
    );
    
    stream.write_all(request.as_bytes()).map_err(|e| format!("Failed to send data to AI enhancer: {}", e))?;
    
    let mut response = Vec::new();
    stream.read_to_end(&mut response).map_err(|e| format!("Failed to read response from AI enhancer: {}", e))?;
    
    let response_str = String::from_utf8_lossy(&response);
    
    // Find the end of HTTP headers (\r\n\r\n)
    if let Some(pos) = response_str.find("\r\n\r\n") {
        let body = &response_str[pos + 4..];
        
        // Parse JSON body
        let parsed: serde_json::Value = serde_json::from_str(body).map_err(|e| format!("Inpainting server returned invalid JSON: {}", e))?;
        if let Some(err) = parsed.get("error") {
            return Err(err.as_str().unwrap_or("Unknown server error").to_string());
        }
        
        if let Some(img) = parsed.get("image") {
            if let Some(img_str) = img.as_str() {
                return Ok(img_str.to_string());
            }
        }
        
        Err("Inpainting server returned invalid response format".to_string())
    } else {
        Err("Inpainting server returned invalid HTTP response".to_string())
    }
}

#[tauri::command]
async fn save_inpainted_image(path: String, base64_data: String) -> Result<(), String> {
    use std::fs::File;
    use std::io::Write;
    
    // Decode base64 string
    let decoded = general_purpose::STANDARD
        .decode(base64_data.trim())
        .map_err(|e| format!("Failed to decode base64 data: {}", e))?;
        
    // Overwrite the original file
    let mut file = File::create(&path).map_err(|e| format!("Failed to open file for writing: {}", e))?;
    file.write_all(&decoded).map_err(|e| format!("Failed to write decoded bytes to disk: {}", e))?;
    
    Ok(())
}

#[tauri::command]
async fn get_subdirectories(dir_path: String) -> Result<Vec<String>, String> {
    tauri::async_runtime::spawn_blocking(move || {
        let path = std::path::Path::new(&dir_path);
        if !path.exists() || !path.is_dir() {
            return Err("Directory does not exist".to_string());
        }
        let mut subdirs = Vec::new();
        if let Ok(entries) = std::fs::read_dir(path) {
            for entry in entries.flatten() {
                let p = entry.path();
                if p.is_dir() {
                    if let Some(name) = p.file_name().and_then(|s| s.to_str()) {
                        subdirs.push(name.to_string());
                    }
                }
            }
        }
        subdirs.sort();
        Ok(subdirs)
    }).await.map_err(|e| e.to_string())?
}

#[tauri::command]
async fn create_new_folder(parent_dir: String, folder_name: String) -> Result<String, String> {
    tauri::async_runtime::spawn_blocking(move || {
        let parent_path = std::path::Path::new(&parent_dir);
        if !parent_path.exists() || !parent_path.is_dir() {
            return Err("Parent directory does not exist".to_string());
        }
        let sanitized = folder_name.replace(|c: char| !c.is_alphanumeric() && c != ' ' && c != '_' && c != '-', "");
        if sanitized.trim().is_empty() {
            return Err("Invalid folder name".to_string());
        }
        let new_folder_path = parent_path.join(&sanitized);
        std::fs::create_dir_all(&new_folder_path).map_err(|e| format!("Failed to create folder: {}", e))?;
        Ok(new_folder_path.to_string_lossy().to_string())
    }).await.map_err(|e| e.to_string())?
}

#[tauri::command]
async fn move_file_on_disk(src_path: String, dest_dir: String) -> Result<String, String> {
    tauri::async_runtime::spawn_blocking(move || {
        let src = std::path::Path::new(&src_path);
        let dest_folder = std::path::Path::new(&dest_dir);
        if !src.exists() {
            return Err("Source file does not exist".to_string());
        }
        if !dest_folder.exists() || !dest_folder.is_dir() {
            return Err("Destination folder does not exist".to_string());
        }
        let file_name = src.file_name().ok_or("Invalid source filename")?;
        let dest_path = dest_folder.join(file_name);
        
        if dest_path.exists() {
            return Err("File already exists in destination folder".to_string());
        }

        let rename_result = std::fs::rename(src, &dest_path);
        if rename_result.is_err() {
            std::fs::copy(src, &dest_path).map_err(|e| format!("Copy fallback failed: {}", e))?;
            std::fs::remove_file(src).map_err(|e| format!("Remove source failed: {}", e))?;
        }
        Ok(dest_path.to_string_lossy().to_string())
    }).await.map_err(|e| e.to_string())?
}

#[tauri::command]
async fn copy_file_on_disk(src_path: String, dest_dir: String) -> Result<String, String> {
    tauri::async_runtime::spawn_blocking(move || {
        let src = std::path::Path::new(&src_path);
        let dest_folder = std::path::Path::new(&dest_dir);
        if !src.exists() {
            return Err("Source file does not exist".to_string());
        }
        if !dest_folder.exists() || !dest_folder.is_dir() {
            return Err("Destination folder does not exist".to_string());
        }
        let file_name = src.file_name().ok_or("Invalid source filename")?;
        let dest_path = dest_folder.join(file_name);
        
        if dest_path.exists() {
            return Err("File already exists in destination folder".to_string());
        }

        std::fs::copy(src, &dest_path).map_err(|e| format!("Copy failed: {}", e))?;
        Ok(dest_path.to_string_lossy().to_string())
    }).await.map_err(|e| e.to_string())?
}

#[tauri::command]
/// Crops an image on disk using FFmpeg, preserving the original format and compression.
/// crop_x, crop_y, crop_w, crop_h are expressed as percentages (0.0–100.0) of the image dimensions.
/// If overwrite is false, the file is saved with a _crop_001 suffix next to the original.
async fn crop_image_on_disk(
    path: String,
    crop_x: f64,
    crop_y: f64,
    crop_w: f64,
    crop_h: f64,
    overwrite: bool,
) -> Result<String, String> {
    use std::process::Command;
    use std::path::Path;

    debug_log(&format!(
        "START crop_image_on_disk: path={}, crop_x={}, crop_y={}, crop_w={}, crop_h={}, overwrite={}",
        path, crop_x, crop_y, crop_w, crop_h, overwrite
    ));

    tauri::async_runtime::spawn_blocking(move || {
        let path_obj = Path::new(&path);
        if !path_obj.exists() {
            return Err("File does not exist".to_string());
        }

        let ext = path_obj.extension().ok_or("No extension")?.to_string_lossy().to_lowercase();
        let stem = path_obj.file_stem().ok_or("No file stem")?.to_string_lossy().to_string();
        let parent = path_obj.parent().ok_or("No parent dir")?;

        // Use ffprobe to get image dimensions
        let mut probe_cmd = Command::new("ffprobe");
        probe_cmd
            .args(["-v", "error", "-select_streams", "v:0",
                   "-show_entries", "stream=width,height",
                   "-of", "csv=s=x:p=0", &path]);
        #[cfg(target_os = "windows")]
        {
            use std::os::windows::process::CommandExt;
            probe_cmd.creation_flags(0x08000000);
        }
        let probe_out = probe_cmd.output().map_err(|e| format!("ffprobe failed: {}", e))?;
        let dims_str = String::from_utf8_lossy(&probe_out.stdout).trim().to_string();
        let parts: Vec<&str> = dims_str.split('x').collect();
        if parts.len() != 2 {
            return Err(format!("Could not parse image dimensions from ffprobe: '{}'", dims_str));
        }
        let img_w: f64 = parts[0].trim().parse().map_err(|_| format!("Bad width: {}", parts[0]))?;
        let img_h: f64 = parts[1].trim().parse().map_err(|_| format!("Bad height: {}", parts[1]))?;

        let px_x = ((crop_x / 100.0) * img_w).round() as u64;
        let px_y = ((crop_y / 100.0) * img_h).round() as u64;
        let px_w = ((crop_w / 100.0) * img_w).round() as u64;
        let px_h = ((crop_h / 100.0) * img_h).round() as u64;

        if px_w == 0 || px_h == 0 {
            return Err("Crop dimensions are zero".to_string());
        }

        let timestamp = std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .unwrap_or_default()
            .as_millis();

        let temp_dir = std::env::temp_dir();
        let temp_file_name = format!("{}_crop_{}.{}", stem, timestamp, ext);
        let temp_path = temp_dir.join(&temp_file_name);

        let crop_filter = format!("crop={}:{}:{}:{}", px_w, px_h, px_x, px_y);

        let mut cmd = Command::new("ffmpeg");
        cmd.arg("-y")
           .arg("-threads").arg("1")
           .arg("-noautorotate")
           .arg("-i").arg(&path)
           .arg("-vf").arg(&crop_filter)
           .arg("-map_metadata").arg("-1");

        // Preserve quality for common formats
        if ext == "jpg" || ext == "jpeg" {
            cmd.arg("-q:v").arg("1");
        } else if ext == "webp" {
            cmd.arg("-quality").arg("100");
        }

        cmd.arg("-update").arg("1");
        cmd.arg(temp_path.to_string_lossy().to_string());

        #[cfg(target_os = "windows")]
        {
            use std::os::windows::process::CommandExt;
            cmd.creation_flags(0x08000000);
        }

        debug_log(&format!("Running ffmpeg crop: {:?}", cmd));
        let output = cmd.output().map_err(|e| format!("Failed to spawn ffmpeg: {}", e))?;
        let stderr_str = String::from_utf8_lossy(&output.stderr).to_string();
        debug_log(&format!("ffmpeg crop exit: {}, stderr: {}", output.status, stderr_str));

        if !output.status.success() {
            if temp_path.exists() { let _ = std::fs::remove_file(&temp_path); }
            return Err(format!("FFmpeg crop failed: {}", stderr_str));
        }
        if !temp_path.exists() {
            return Err("FFmpeg ran but crop file was not created".to_string());
        }

        let target_path = if overwrite {
            std::path::PathBuf::from(&path)
        } else {
            // Find an unused _crop_001, _crop_002 … name
            let mut index = 1u32;
            let mut candidate = parent.join(format!("{}_crop_{:03}.{}", stem, index, ext));
            while candidate.exists() {
                index += 1;
                candidate = parent.join(format!("{}_crop_{:03}.{}", stem, index, ext));
            }
            candidate
        };

        std::fs::copy(&temp_path, &target_path)
            .map_err(|e| format!("Failed to write crop to destination: {}", e))?;
        let _ = std::fs::remove_file(&temp_path);

        debug_log(&format!("Crop saved to: {:?}", target_path));
        Ok(target_path.to_string_lossy().to_string())
    }).await.map_err(|e| e.to_string())?
}

#[tauri::command]
async fn duplicate_file_on_disk(src_path: String) -> Result<String, String> {
    tauri::async_runtime::spawn_blocking(move || {
        let src = std::path::Path::new(&src_path);
        if !src.exists() {
            return Err("Source file does not exist".to_string());
        }
        let parent = src.parent().ok_or("Invalid parent directory")?;
        let file_stem = src.file_stem().ok_or("Invalid file stem")?.to_string_lossy().to_string();
        let ext = src.extension().map(|e| e.to_string_lossy().to_string()).unwrap_or_default();
        
        let ext_str = if ext.is_empty() {
            "".to_string()
        } else {
            format!(".{}", ext)
        };
        
        let mut index = 1;
        let mut target_path = parent.join(format!("{}_{:03}{}", file_stem, index, ext_str));
        while target_path.exists() {
            index += 1;
            target_path = parent.join(format!("{}_{:03}{}", file_stem, index, ext_str));
        }

        std::fs::copy(src, &target_path).map_err(|e| format!("Duplicate copy failed: {}", e))?;
        Ok(target_path.to_string_lossy().to_string())
    }).await.map_err(|e| e.to_string())?
}

#[tauri::command]
async fn secure_delete_file(path: String) -> Result<(), String> {
    tauri::async_runtime::spawn_blocking(move || {
        let path_obj = std::path::Path::new(&path);
        if !path_obj.exists() {
            return Err("File not found".to_string());
        }
        
        let metadata = std::fs::metadata(&path_obj).map_err(|e| e.to_string())?;
        if !metadata.is_file() {
            return Err("Only files can be securely deleted".to_string());
        }
        
        let file_size = metadata.len();
        
        // 2 passes of overwriting with zeroes
        for _ in 0..2 {
            let mut file = std::fs::OpenOptions::new()
                .write(true)
                .open(&path_obj)
                .map_err(|e| format!("Failed to open file for overwrite: {}", e))?;
            
            use std::io::{Seek, SeekFrom, Write};
            file.seek(SeekFrom::Start(0)).map_err(|e| e.to_string())?;
            
            let chunk = vec![0u8; 65536]; // 64KB chunks
            let mut remaining = file_size;
            while remaining > 0 {
                let write_size = remaining.min(65536) as usize;
                file.write_all(&chunk[..write_size])
                    .map_err(|e| format!("Failed to overwrite file content: {}", e))?;
                remaining -= write_size as u64;
            }
            file.flush().map_err(|e| format!("Failed to flush file to disk: {}", e))?;
        }
        
        // Truncate to 0 bytes
        let file = std::fs::OpenOptions::new()
            .write(true)
            .open(&path_obj)
            .map_err(|e| format!("Failed to open file for truncation: {}", e))?;
        file.set_len(0).map_err(|e| format!("Failed to truncate file: {}", e))?;
        
        std::fs::remove_file(&path_obj).map_err(|e| format!("Failed to delete file from disk: {}", e))?;
        Ok(())
    }).await.map_err(|e| e.to_string())?
}

static AI_HARDWARE_MODE: std::sync::OnceLock<String> = std::sync::OnceLock::new();

#[tauri::command]
fn get_ai_hardware_status() -> String {
    AI_HARDWARE_MODE.get().cloned().unwrap_or_else(|| "Detecting...".to_string())
}

#[tauri::command]
async fn span_all_monitors(window: tauri::Window) -> Result<(), String> {
    println!("--- span_all_monitors triggered ---");
    let monitors = window.available_monitors().map_err(|e| {
        println!("Error getting available monitors: {}", e);
        e.to_string()
    })?;
    println!("Found {} monitors", monitors.len());
    for (i, m) in monitors.iter().enumerate() {
        println!("  Monitor [{}]: Name={:?}, Position={:?}, Size={:?}, ScaleFactor={}", i, m.name(), m.position(), m.size(), m.scale_factor());
    }

    if monitors.is_empty() {
        return Err("No monitors found".into());
    }

    let mut min_x = i32::MAX;
    let mut min_y = i32::MAX;
    let mut max_x = i32::MIN;
    let mut max_y = i32::MIN;

    for m in &monitors {
        let pos = m.position();
        let size = m.size();
        let x1 = pos.x;
        let y1 = pos.y;
        let x2 = pos.x + size.width as i32;
        let y2 = pos.y + size.height as i32;

        if x1 < min_x { min_x = x1; }
        if y1 < min_y { min_y = y1; }
        if x2 > max_x { max_x = x2; }
        if y2 > max_y { max_y = y2; }
    }

    let width = (max_x - min_x) as u32;
    let height = (max_y - min_y) as u32;
    println!("Calculated Spanning Area: x={}, y={}, width={}, height={}", min_x, min_y, width, height);

    // Unmaximize first, give OS time to settle
    let _ = window.unmaximize();
    std::thread::sleep(std::time::Duration::from_millis(150));

    // Use raw Win32 SetWindowPos for a single atomic position+size call.
    // Tauri's sequential set_position then set_size can be overridden by the Windows
    // compositor between calls — SetWindowPos avoids this by applying both at once.
    #[cfg(target_os = "windows")]
    {
        use windows::Win32::UI::WindowsAndMessaging::{SetWindowPos, SWP_NOZORDER, SWP_NOACTIVATE, SWP_FRAMECHANGED};
        use windows::Win32::Foundation::HWND;

        let hwnd = window.hwnd().map_err(|e| e.to_string())?;
        let hwnd = HWND(hwnd.0 as *mut std::ffi::c_void);
        unsafe {
            SetWindowPos(
                hwnd,
                None,
                min_x,
                min_y,
                width as i32,
                height as i32,
                SWP_NOZORDER | SWP_NOACTIVATE | SWP_FRAMECHANGED,
            ).map_err(|e| e.to_string())?;
        }
        println!("--- span_all_monitors complete (Win32 SetWindowPos) ---");
    }

    #[cfg(not(target_os = "windows"))]
    {
        let _ = window.set_decorations(false);
        let _ = window.set_position(tauri::Position::Physical(tauri::PhysicalPosition { x: min_x, y: min_y }));
        let _ = window.set_size(tauri::Size::Physical(tauri::PhysicalSize { width, height }));
        println!("--- span_all_monitors complete (fallback) ---");
    }

    Ok(())
}

#[tauri::command]
async fn unspan_monitors(window: tauri::Window) -> Result<(), String> {
    println!("--- unspan_monitors triggered ---");
    if let Err(e) = window.set_decorations(false) {
        println!("  set_decorations error: {}", e);
    }
    if let Err(e) = window.set_size(tauri::Size::Physical(tauri::PhysicalSize { width: 1280, height: 720 })) {
        println!("  set_size error: {}", e);
    }
    if let Err(e) = window.center() {
        println!("  center error: {}", e);
    }
    println!("--- unspan_monitors complete ---");
    Ok(())
}

fn spawn_symphony_backend() {
    std::thread::spawn(move || {
        // 1. Check if port 8000 is already active
        if std::net::TcpStream::connect("127.0.0.1:8000").is_ok() {
            println!("Symphony Backend already online on port 8000.");
            return;
        }

        // 2. Robust directory traversal to locate sibling "CosmoStudio"
        if let Ok(current_dir) = std::env::current_dir() {
            let mut check_dir = Some(current_dir.as_path());
            
            while let Some(dir) = check_dir {
                // Check if CosmoStudio is a sibling of the current check directory
                let sibling_studio = dir.join("CosmoStudio");
                if sibling_studio.exists() && sibling_studio.join("start_backend.ps1").exists() {
                    println!("Auto-starting Symphony Backend from: {:?}", sibling_studio);
                    let mut cmd = std::process::Command::new("powershell.exe");
                    cmd.args(&[
                        "-ExecutionPolicy",
                        "Bypass",
                        "-File",
                        "start_backend.ps1",
                    ]);
                    cmd.current_dir(sibling_studio);
                    
                    #[cfg(target_os = "windows")]
                    {
                        use std::os::windows::process::CommandExt;
                        cmd.creation_flags(0x08000000); // CREATE_NO_WINDOW
                    }

                    if let Err(e) = cmd.spawn() {
                        println!("Failed to auto-start Symphony Backend: {:?}", e);
                    } else {
                        println!("Symphony Backend process spawned successfully.");
                    }
                    return;
                }
                check_dir = dir.parent();
            }
            println!("Could not locate CosmoStudio directory from current path: {:?}", std::env::current_dir());
        }
    });
}

fn main() {
    // Self-healing: Clean up .window-state.json to prevent dynamic popout windows from loading in a loop
    if let Some(mut config_dir) = dirs::config_dir() {
        config_dir.push("com.cosmo.symphony");
        let state_file = config_dir.join(".window-state.json");
        if state_file.exists() {
            if let Ok(content) = std::fs::read_to_string(&state_file) {
                if let Ok(mut json) = serde_json::from_str::<serde_json::Value>(&content) {
                    if let Some(obj) = json.as_object_mut() {
                        // Remove all window state keys that start with "pop-" or are not "main"
                        let keys_to_remove: Vec<String> = obj.keys()
                            .filter(|k| k.starts_with("pop-") || *k != "main")
                            .map(|k| k.to_string())
                            .collect();
                        
                        if !keys_to_remove.is_empty() {
                            for k in keys_to_remove {
                                obj.remove(&k);
                            }
                            if let Ok(updated_content) = serde_json::to_string(&json) {
                                let _ = std::fs::write(&state_file, updated_content);
                            }
                        }
                    }
                }
            }
        }
    }

    tauri::Builder::default()
        .plugin(tauri_plugin_opener::init())
        .plugin(tauri_plugin_drag::init())
        .plugin(
            tauri_plugin_log::Builder::default()
                .targets([
                    Target::new(TargetKind::Stdout),
                    Target::new(TargetKind::Webview),
                ])
                .build(),
        )
        .plugin(tauri_plugin_shell::init())
        .plugin(tauri_plugin_dialog::init())
        .plugin(tauri_plugin_fs::init())
        .plugin(tauri_plugin_window_state::Builder::default().build())
        .register_uri_scheme_protocol("cosmo", |_app, request| {
            // HIGH-PERFORMANCE ASYNC DRIVE ENGINE (v4)
            // This handler is optimized for 24-core parallel streaming
            
            // Handle CORS Preflight
            if request.method() == tauri::http::Method::OPTIONS {
                return tauri::http::Response::builder()
                    .status(200)
                    .header("Access-Control-Allow-Origin", "*")
                    .header("Access-Control-Allow-Methods", "GET, POST, OPTIONS, RANGE")
                    .header("Access-Control-Allow-Headers", "Range, Content-Type")
                    .header("Access-Control-Max-Age", "86400")
                    .body(Vec::new())
                    .unwrap();
            }

            let uri_str = request.uri().to_string();
            println!("Cosmo Protocol Request: {}", uri_str);
            let path_raw = uri_str
                .replace("cosmo://localhost/", "") 
                .replace("cosmo://media/", "")
                .replace("cosmo://video/", "")
                .replace("cosmo://", "")
                .replace("http://cosmo.localhost/video/", "")
                .replace("http://cosmo.localhost/", "")
                .replace("https://cosmo.localhost/video/", "")
                .replace("https://cosmo.localhost/", "");

            let path_decoded = match urlencoding::decode(&path_raw) {
                Ok(decoded) => decoded.into_owned(),
                Err(_) => return tauri::http::Response::builder().status(400).body(Vec::new()).unwrap(),
            };

            // Remove any leading slashes or backslashes that arise from Webview2 custom scheme normalization
            let mut clean_path = path_decoded.as_str();
            while clean_path.starts_with('/') || clean_path.starts_with('\\') {
                clean_path = &clean_path[1..];
            }

            // SECURITY: Proper path traversal prevention with canonicalization
            let mut components = Vec::new();
            let mut has_prefix = false;
            
            for component in std::path::Path::new(&clean_path).components() {
                match component {
                    std::path::Component::Prefix(p) => {
                        components.push(p.as_os_str());
                        has_prefix = true;
                    }
                    std::path::Component::RootDir => {
                        // Preserve RootDir if it's the first or after a prefix
                        if components.is_empty() || has_prefix {
                            components.push(component.as_os_str());
                        }
                    }
                    std::path::Component::Normal(name) => components.push(name),
                    std::path::Component::CurDir => continue,
                    std::path::Component::ParentDir => {
                        if !components.is_empty() {
                            components.pop();
                        } else {
                            return tauri::http::Response::builder()
                                .status(403) // Forbidden
                                .body(Vec::new())
                                .unwrap();
                        }
                    }
                }
            }

            // Reconstruct safe path
            let mut safe_path = std::path::PathBuf::new();
            for comp in components {
                safe_path.push(comp);
            }

            // Ensure path is absolute
            if !safe_path.is_absolute() {
                return tauri::http::Response::builder()
                    .status(400)
                    .body(Vec::new())
                    .unwrap();
            }

            if !safe_path.exists() {
                return tauri::http::Response::builder()
                    .status(404)
                    .header("Access-Control-Allow-Origin", "*")
                    .body(Vec::new())
                    .unwrap();
            }

            let path = safe_path;

            // Using standard fs here for metadata, but we'll use tokio for the stream
            let file_len = std::fs::metadata(&path).map(|m| m.len()).unwrap_or(0);
            
            let range = request
                .headers()
                .get("range")
                .and_then(|r: &tauri::http::HeaderValue| r.to_str().ok());

            let (start, end) = if let Some(r) = range {
                let r_clean = r.replace("bytes=", "");
                let range_parts: Vec<&str> = r_clean.split('-').collect();
                let start = range_parts[0].parse::<u64>().unwrap_or(0);
                let end = if range_parts.len() > 1 && !range_parts[1].is_empty() {
                    range_parts[1].parse::<u64>().unwrap_or(file_len - 1)
                } else {
                    file_len - 1
                };
                (start, end)
            } else {
                (0, file_len.saturating_sub(1))
            };

            // Progressive streaming logic with a safe chunk cap (4MB) to prevent OOM
            let mut end = end;
            let max_chunk = 4 * 1024 * 1024; // 4MB maximum buffer allocation size
            if end - start + 1 > max_chunk as u64 {
                end = start + max_chunk as u64 - 1;
            }
            if end >= file_len {
                end = file_len.saturating_sub(1);
            }

            let chunk_size = (end - start + 1) as usize;
            
            let mime = match path.extension().and_then(|s| s.to_str()).map(|s| s.to_lowercase()).as_deref().unwrap_or("") {
                "mp4" | "m4v" => "video/mp4",
                "webm" => "video/webm",
                "mov" => "video/quicktime",
                "mkv" => "video/x-matroska",
                "avi" => "video/x-msvideo",
                "3gp" => "video/3gpp",
                "flv" => "video/x-flv",
                "wmv" => "video/x-ms-wmv",
                "jpg" | "jpeg" => "image/jpeg",
                "png" => "image/png",
                "gif" => "image/gif",
                "webp" => "image/webp",
                "bmp" => "image/bmp",
                "svg" => "image/svg+xml",
                "tiff" | "tif" => "image/tiff",
                _ => "application/octet-stream",
            };

            use std::io::{Read, Seek, SeekFrom};
            let mut buffer = vec![0; chunk_size];
            let mut bytes_read = 0;
            
            let file_open_result = std::fs::File::open(&path).and_then(|mut f| {
                f.seek(SeekFrom::Start(start))?;
                let mut taken = f.take(chunk_size as u64);
                while bytes_read < chunk_size {
                    match taken.read(&mut buffer[bytes_read..]) {
                        Ok(0) => break, // EOF reached
                        Ok(n) => bytes_read += n,
                        Err(ref e) if e.kind() == std::io::ErrorKind::Interrupted => continue,
                        Err(e) => return Err(e),
                    }
                }
                Ok(())
            });

            if file_open_result.is_err() || bytes_read == 0 {
                return tauri::http::Response::builder()
                    .status(404)
                    .header("Access-Control-Allow-Origin", "*")
                    .body(Vec::new())
                    .unwrap();
            }

            buffer.truncate(bytes_read);
            let response_end = start + bytes_read as u64 - 1;

            tauri::http::Response::builder()
                .status(if start > 0 || bytes_read < file_len as usize { 206 } else { 200 })
                .header("Content-Type", mime)
                .header("Accept-Ranges", "bytes")
                .header("Content-Length", bytes_read)
                .header("Content-Range", format!("bytes {}-{}/{}", start, response_end, file_len))
                .header("Access-Control-Allow-Origin", "*")
                .header("Access-Control-Allow-Methods", "GET, OPTIONS, RANGE")
                .header("Access-Control-Allow-Headers", "Range, Content-Type")
                .header("Access-Control-Allow-Private-Network", "true")
                .body(buffer)
                .unwrap()
        })
        .manage(AppState {
            sys: Mutex::new(System::new_with_specifics(
                RefreshKind::nothing().with_cpu(CpuRefreshKind::everything()),
            )),
            last_refresh: Mutex::new(std::time::Instant::now()),
        })
        .manage(LaunchArgs(Mutex::new(None)))
        .invoke_handler(tauri::generate_handler![
            get_launch_args,
            cosmo_log,
            select_folder_cmd,
            get_folder_videos,
            save_snapshot,
            save_persistence,
            load_persistence,
            open_folder,
            set_always_on_top,
            pop_out,
            get_telemetry,
            get_video_metadata,
            rename_video,
            recycle_unit,
            rotate_media_on_disk,
            mirror_media_on_disk,
            apply_color_adjustments_on_disk,
            get_drag_icon_path,
            extract_subject_on_disk,
            upscale_image,
            enhance_image_crop,
            auto_erase_watermark,
            save_inpainted_image,
            get_ai_hardware_status,
            span_all_monitors,
            unspan_monitors,
            snapshot_video_frame,
            get_subdirectories,
            create_new_folder,
            move_file_on_disk,
            copy_file_on_disk,
            duplicate_file_on_disk,
            crop_image_on_disk,
            secure_delete_file,
            exit_app
        ])
        .setup(|app| {
            use tauri::Manager;

            // Auto-start Symphony Backend (FastAPI on port 8000) if not running
            spawn_symphony_backend();

            // Check for launch arguments (Open With)
            let args: Vec<String> = std::env::args().collect();
            if args.len() > 1 {
                let potential_path = &args[1];
                if std::path::Path::new(potential_path).exists() {
                    let launch_args = app.state::<LaunchArgs>();
                    let mut guard = launch_args.0.lock().unwrap();
                    *guard = Some(potential_path.clone());
                }
            }
            
            // Spawn background task to detect AI GPU vs CPU capability
            let app_handle = app.handle().clone();
            std::thread::spawn(move || {
                let mut has_cuda = false;
                if let Ok((runner, args)) = resolve_enhancer_command(Some(&app_handle)) {
                    let mut check_args = args;
                    check_args.push("--check-cuda".to_string());
                    
                    let mut cmd = std::process::Command::new(&runner);
                    cmd.args(&check_args);

                    // Set writable current directory so Python libraries don't fail trying to create dirs/files in system folders
                    if let Ok(app_data) = app_handle.path().app_data_dir() {
                        let _ = std::fs::create_dir_all(&app_data);
                        cmd.current_dir(&app_data);
                    }

                    // Pass models directory to CUDA check process
                    if let Some(models_dir) = resolve_models_dir(Some(&app_handle)) {
                        cmd.env("COSMO_MODELS_DIR", &models_dir);
                    }
                    #[cfg(target_os = "windows")]
                    {
                        use std::os::windows::process::CommandExt;
                        cmd.creation_flags(0x08000000); // CREATE_NO_WINDOW
                    }
                    
                    if let Ok(output) = cmd.output() {
                        let out_str = String::from_utf8_lossy(&output.stdout).trim().to_lowercase();
                        if out_str.contains("cuda") {
                            has_cuda = true;
                        }
                    }
                }
                
                let mode_str = if has_cuda {
                    "GPU (Nvidia CUDA)".to_string()
                } else {
                    "CPU (Bilateral Filter Fallback)".to_string()
                };
                let _ = AI_HARDWARE_MODE.set(mode_str);
            });

            if let Some(window) = app.get_webview_window("main") {
                let _ = window.show();
                let _ = window.set_focus();
            }
            Ok(())
        })
        .run(tauri::generate_context!())
        .expect("error while running tauri application");
}
